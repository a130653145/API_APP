//
//  File.swift
//  OAO
//
//  Created by User13 on 2020/12/9.
//
//https://github.com/fanzeyi/pokemon.json

import SwiftUI

import Foundation

struct TaskEntry_items: Codable  {
    
    let name: Item
    let id: Int
}

struct Item: Codable {
   let japanese: String?
    let english: String?
   let chinese: String?
}

struct items: View {

 @State var results = [TaskEntry_items]()

 var body: some View {
     List(results, id: \.id) { item in
         VStack(alignment: .leading) {
            Text(String(item.id))
            Text(item.name.japanese ?? "None")
            Text(item.name.english ?? "None")
            Text(item.name.chinese ?? "None")
         }
     }.onAppear(perform: loadData_item)
    

 }
    
    
    func loadData_item() {
     guard let url = URL(string: "https://raw.githubusercontent.com/fanzeyi/pokemon.json/master/items.json") else {
        print("Your API end point is Invalid")
        return
     }
     let request = URLRequest(url: url)
         URLSession.shared.dataTask(with: request) { data, response, error in
             if let data = data {
                 if let response = try? JSONDecoder().decode([TaskEntry_items].self, from: data) {
                         DispatchQueue.main.async {
                            self.results = response
                         }
                         return
                 }
             }
         }.resume()
     }

   
}


struct items_Previews: PreviewProvider {
    static var previews: some View {
        items()
    }
}
