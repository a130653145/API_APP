
import SwiftUI

struct mainlist: View {
    var body: some View {
        ZStack{
                    TabView {
                        home_page()
                            .tabItem {
                                Image(systemName: "house.fill")
                                Text("主頁")
                        }
                        pokemon()
                            .tabItem {
                                Text("pokemon")
                                Image("皮卡丘")
                                    
                                                                    
                                
                        }
                        items()
                            .tabItem {
                                Image("大師球")
                                Text("pokemon_items")
                        }
                        
                        digimon()
                            .tabItem {
                                Image("暴龍獸")
                                Text("digimon")
                        }
                    }
                    .accentColor(.orange)
                }
    }
}

struct mainlist_Previews: PreviewProvider {
    static var previews: some View {
        mainlist()
    }
}
