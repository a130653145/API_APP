//
//  home_page.swift
//  hw1
//
//  Created by User13 on 2020/12/9.
//
//https://github.com/fanzeyi/pokemon.json
import SwiftUI

struct home_page: View{
        var body: some View{
        TextEditor(text:.constant("""
        歡迎使用
        ＰＯＫＥＭＯＮ大全
        數碼寶貝？
    
    """)).font(.system(size:20))
        }
    }
struct home_page_Previews: PreviewProvider {
    static var previews: some View {
        home_page()
    }
}
