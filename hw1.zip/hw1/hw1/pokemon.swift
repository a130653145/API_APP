//
//  File.swift
//  OAO
//
//  Created by User13 on 2020/12/9.
//
//https://github.com/fanzeyi/pokemon.json

import SwiftUI

import Foundation

struct TaskEntry_pokemon: Codable  {
    let id: Int
    let name: pokemon_name
    let type: [String]
    let base: pokemon_bases
    
    
}

struct pokemon_name: Codable {
   let japanese: String?
   let english: String?
   let chinese: String?
   let french: String?
}


struct pokemon_bases: Codable {
   let HP: Int?
   let Attack: Int?
   let Defense: Int?
   let Sp_Attack: Int?
   let Sp_Defense: Int?
   let Speed: Int?
    
   enum CodingKeys: String, CodingKey { //change_keys_name
        case HP
        case Attack
        case Defense
        case Sp_Attack = "Sp. Attack"
        case Sp_Defense = "Sp. Defense"
        case Speed
      }

}

struct pokemon: View {

 @State var results = [TaskEntry_pokemon]()
    var idx: Int = 0
 var body: some View {
     List(results, id: \.id) { item in
         VStack(alignment: .leading) {
            Text("圖鑑ＩＤ：\(item.id)")
            Text("NAME:")
            Group{
                Text(item.name.japanese ?? "???")
                Text(item.name.english ?? "???")
                Text(item.name.chinese ?? "???")
                Text(item.name.french ?? "???")
            }
            Text("TYPE:")
            Group{
                
                 //這會崩潰
                ForEach(0..<item.type.count, id: \.self) { typesss in
                    Text("\(item.type[typesss])")
                    }
                
              
            }
           
            Text("BASE:")
            Group{
                Text("HP: \(item.base.HP ?? 0) ")
                Text("Attack: \(item.base.Attack ?? 0)")
                Text("Defense: \(item.base.Defense ?? 0)")
                Text("Sp_Attack: \(item.base.Sp_Attack ?? 0)")
                Text("Sp_Defense: \(item.base.Sp_Defense ?? 0)")
                Text("Speed: \(item.base.Speed ?? 0)")
            
            }
            
          
         }
     }.onAppear(perform: loadData_pokemon)
    

 }
    
    
    func loadData_pokemon() {
     guard let url = URL(string: "https://raw.githubusercontent.com/fanzeyi/pokemon.json/master/pokedex.json") else {
        print("Your API end point is Invalid")
        return
     }
     let request = URLRequest(url: url)
         URLSession.shared.dataTask(with: request) { data, response, error in
             if let data = data {
                 if let response = try? JSONDecoder().decode([TaskEntry_pokemon].self, from: data) {
                         DispatchQueue.main.async {
                            self.results = response
                         }
                         return
                 }
             }
         }.resume()
     }

   
}


struct pokemon_Previews: PreviewProvider {
    static var previews: some View {
        pokemon()
    }
}
