//
//  hw1App.swift
//  hw1
//
//  Created by User13 on 2020/9/23.
//

import SwiftUI

@main
struct hw1App: App {
    var body: some Scene {
        WindowGroup {
            mainlist()
        }
    }
}
