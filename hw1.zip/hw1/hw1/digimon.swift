//https://digimon-api.vercel.app/api/digimon
//下面的指示好看
//https://github.com/heyshadowsmith/digimon-api/blob/master/database/Digimon.js

import SwiftUI

import Foundation

struct TaskEntry_digimon: Codable  {

    let name: String
    let img: String
    let level: String
}



struct digimon: View {

 @State var results = [TaskEntry_digimon]()
 //@State var idx: Int = 0
    
 var body: some View {
    List(results, id: \.name) { item in
         VStack(alignment: .leading) {
            
            
                Text("ＮＡＭＥ：\(item.name)")
                Text("ＩＭＧ：\(item.img)")
                Text("ＬＥＶＥＬ：\(item.level)")
                
            
            
            
         }
     }.onAppear(perform: loadData_pokemon)
    

 }
    
    
    func loadData_pokemon() {
     guard let url = URL(string: "https://digimon-api.vercel.app/api/digimon") else {
        print("Your API end point is Invalid")
        return
     }
     let request = URLRequest(url: url)
         URLSession.shared.dataTask(with: request) { data, response, error in
             if let data = data {
                 if let response = try? JSONDecoder().decode([TaskEntry_digimon].self, from: data) {
                         DispatchQueue.main.async {
                            self.results = response
                         }
                         return
                 }
             }
         }.resume()
     }

   
}


struct digimon_Previews: PreviewProvider {
    static var previews: some View {
        digimon()
    }
}

